<template>
	<span>
		{{ spanValue }}
	</span>
</template>

<script setup lang="ts">
defineProps(["spanValue"]);
</script>

<style scoped></style>

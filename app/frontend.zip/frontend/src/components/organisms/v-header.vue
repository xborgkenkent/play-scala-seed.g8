<template>
	<v-logo>
		<h1>Kanban</h1>
	</v-logo>
</template>

<script setup lang="ts">
import VLogo from "../atoms/v-logo.vue";
</script>

<style scoped></style>

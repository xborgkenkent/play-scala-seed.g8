<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from "vue";

</script>
<style scoped></style>
